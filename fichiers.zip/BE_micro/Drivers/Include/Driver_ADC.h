#ifndef MYADC_H
#define MYADC_H
#include "stm32f10x.h"

void Init_ADC(void);
int ADC_GetValue(int chan);

#endif
			
